<?php

/** Configuration Variables **/

define ('DEVELOPMENT_ENVIRONMENT',true);

//database connection 
define('DB_NAME', 'framework');
define('DB_USER', 'ROOT_FRONT');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');

define('BASE_PATH','http://localhost/edge/projects/kloppend-hart-antwerpen/version_002/front');


define('PAGINATE_LIMIT', '5');