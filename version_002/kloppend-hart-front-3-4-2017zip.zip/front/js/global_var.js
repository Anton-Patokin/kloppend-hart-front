var ROOT_FRONT ="http://localhost/edge/projects/kloppend-hart-antwerpen/version_002/front/";
var center = { latitude: 51.218826, longitude: 4.402950 };