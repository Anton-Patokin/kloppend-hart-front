app.controller("section7", function ($scope, $interval) {
    console.log('section7 is loaded')
});