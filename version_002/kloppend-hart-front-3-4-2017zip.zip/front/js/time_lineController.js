app.controller("timeLineController", function ($scope, $timeout) {

    
});