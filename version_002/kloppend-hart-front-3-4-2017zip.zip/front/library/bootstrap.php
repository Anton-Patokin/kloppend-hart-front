<?php

require_once (ROOT_FRONT . DS . 'config' . DS . 'config.php');
require_once (ROOT_FRONT . DS . 'config' . DS . 'routing.php');
require_once(ROOT_FRONT . DS . 'library' . DS . 'shared.php');