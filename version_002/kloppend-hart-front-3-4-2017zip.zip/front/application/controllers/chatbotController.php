<?php



class chatbotController{

    public function test(){
        echo 'test';
    }

}



//require_once 'C:\xampp\htdocs\edge\projects\kloppend-hart-antwerpen\version_002\settings.php';
//DEFINE('ROOT_FRONT', 'C:\xampp\htdocs\edge\projects\kloppend-hart-antwerpen\version_002\front\\');
//require_once ROOT_FRONT . '/application/controllers/placeController.php';
//
//
//$place = new placeController();
//
//
//if(isset($_GET['category'])){
//    $category= $_GET['category'];
//    var_dump($category) ;
//    var_dump($place->getSubcategories($category));
//}


//{
//    "messages": [{
//    "text": "testRedirectInQuickReply",
//		"quick_replies": [{
//        "set_attributes": {
//            "typeZaak": "Type zaak"
//			},
//			"title": "Type zaak",
//			"block_names": ["TopZaken"]
//		}, {
//        "set_attributes": {
//            "attribute": "Type zaak"
//			},
//			"title": "Type zaak",
//			"block_names": ["TopZaken"]
//		}]
//	}]
//}
?>