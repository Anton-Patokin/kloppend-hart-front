<?php
class heatmapModel extends Model{
    
}
?>
