<?php

class weatherModel extends Model{
    
}
?>
