<?php

class instagramModel extends Model{
    
}
?>
