<?php
class twitterModel extends Model{
    
}
?>
