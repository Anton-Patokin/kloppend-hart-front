<?php

class Model {
    protected $_model;
    
    function __construct() {
       
    }
    
    function destruct(){
        
    }
}
